function carregarAgendamentos() {
    var email = sessionStorage.getItem("emailLogado");

    if (!email) {
        window.location.href = '/Login';
        return;
    }

    fetch('http://localhost:8080/MeusAgendamentos/listar?email=' + encodeURIComponent(email), {
        method: 'GET',
        headers: { 'Accept': 'application/json' }
    })
        .then(function (r) { return r.json(); })
        .then(function (lista) { popularTabela(lista); })
        .catch(function (e) { console.error(e); });
}

function popularTabela(lista) {
    var tabela = document.getElementById('listaAgendamentos');
    tabela.innerHTML = "";
    lista.forEach(function (ag) {
        tabela.innerHTML += "<tr>" +
            "<td>" + ag.paciente + "</td>" +
            "<td>" + ag.procedimento + "</td>" +
            "<td>" + ag.data + "</td>" +
            "<td>" + ag.horario + "</td>" +
            "<td><button type='button' class='btn-sair' onclick='cancelar(" + ag.id + ")'>Cancelar</button></td>" +
            "</tr>";
    });
}

function cancelar(id) {
    var cancelamentoDTO = { id: id };

    var url = 'http://localhost:8080/MeusAgendamentos/cancelar';
    var configrequest = {
        method: 'POST',
        headers: { 'Accept': 'application/json', 'Content-Type': 'application/json' },
        body: JSON.stringify(cancelamentoDTO)
    };

    fetch(url, configrequest)
        .then(function (responce) {
            if (responce.ok) {
                alert("Agendamento cancelado!");
                carregarAgendamentos();
            } else {
                alert("Erro ao cancelar.");
            }
        })
        .catch(function (error) { console.error(error); });
}

window.onload = carregarAgendamentos;