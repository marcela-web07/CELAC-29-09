async function cadastrarServico() {
    const nome = document.getElementById("nome").value;
    const descricao = document.getElementById("descricao").value;
    const valor = parseFloat(document.getElementById("valor").value);

    const servicoDTO = {
        nome: nome,
        descricao: descricao,
        valor: valor
    };

    try {
        const response = await fetch("/ServicosADM/cadastrar", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(servicoDTO)
        });

        if (response.ok) {
            alert("Serviço cadastrado com sucesso!");
            window.location.reload();
        } else {
            alert("Erro ao cadastrar serviço.");
        }
    } catch (error) {
        alert("Erro de conexão: " + error);
    }
}