var agendamentoDTO = {
    paciente: "",
    procedimento: "",
    data: "",
    horario: "",
    observacoes: ""
}

// roda assim que a página carrega: lê o procedimento da URL
window.onload = function () {
    var params = new URLSearchParams(window.location.search);
    var procedimentoEscolhido = params.get("procedimento");

    if (procedimentoEscolhido) {
        // mostra na tela (se você tiver um elemento pra exibir)
        var display = document.getElementById("nomeProcedimento");
        if (display) {
            display.textContent = procedimentoEscolhido;
        }
        // guarda no campo escondido
        document.getElementById("procedimento").value = procedimentoEscolhido;
    }
};

function agendar() {

    var paciente = document.getElementById("paciente").value;
    var procedimento = document.getElementById("procedimento").value;
    var data = document.getElementById("data").value;
    var horario = document.getElementById("horario").value;
    var observacoes = document.getElementById("observacoes").value;

    // validação: barra se faltar procedimento, data ou horário
    if (paciente === "" || procedimento === "" || data === "" || horario === "") {
        alert("Preencha data e horário!");
        return;
    }

    agendamentoDTO.paciente = paciente;
    agendamentoDTO.procedimento = procedimento;
    agendamentoDTO.data = data;
    agendamentoDTO.horario = horario;
    agendamentoDTO.observacoes = observacoes;

    agendamentoDTO.emailUsuario = sessionStorage.getItem("emailLogado");
    var url = 'http://localhost:8080/Agenda/agendar';
    var configrequest = {
        method: 'POST',
        headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(agendamentoDTO)
    };

    fetch(url, configrequest)
        .then(function (responce) {
            if (responce.ok) {
                alert("Agendamento confirmado!");
                window.location.href = '/Home';
            } else {
                alert("Erro ao agendar. Tente novamente.");
            }
        })
        .catch(function (error) {
            console.error(error);
        });
}