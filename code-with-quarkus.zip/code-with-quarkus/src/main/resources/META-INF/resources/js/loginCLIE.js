var autenticacaoDTO = {
    identificador: "",
    senha: ""
}

function autenticar() {

    autenticacaoDTO.identificador = document.getElementById("email").value;
    autenticacaoDTO.senha = document.getElementById("senha").value;

    var url = 'http://localhost:8080/Login/autenticar';
    var configrequest = {
        method: 'POST',
        headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(autenticacaoDTO)
    };

    fetch(url, configrequest)
        .then(function (responce) {
            if (responce.ok) {
                sessionStorage.setItem("emailLogado", autenticacaoDTO.identificador);
                window.location.href = '/Home';
            } else {
                alert("Digite um Email ou Senha corretos. Se ainda não possui, cadastre-se!");
            }

        })
        .catch(function (error) {
            console.error(error);
        })
}