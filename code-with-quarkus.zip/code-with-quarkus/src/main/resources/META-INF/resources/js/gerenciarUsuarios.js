function promover(email) {
    enviarAcao('/GerenciarUsuarios/promover', email, "Usuário promovido a ADM!");
}

function rebaixar(email) {
    enviarAcao('/GerenciarUsuarios/rebaixar', email, "Usuário rebaixado a cliente!");
}

function enviarAcao(url, email, mensagem) {

    var dto = {
        email: email
    };

    var configrequest = {
        method: 'POST',
        headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(dto)
    };

    fetch('http://localhost:8080' + url, configrequest)
        .then(function (responce) {
            if (responce.ok) {
                alert(mensagem);
                location.reload();   // recarrega pra atualizar a lista
            } else {
                alert("Erro ao executar a ação.");
            }
        })
        .catch(function (error) {
            console.error(error);
        });
}