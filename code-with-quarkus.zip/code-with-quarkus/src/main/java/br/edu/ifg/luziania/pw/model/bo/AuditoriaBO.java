package br.edu.ifg.luziania.pw.model.bo;

import br.edu.ifg.luziania.pw.model.dto.LogAuditoriaDTO;
import jakarta.enterprise.context.RequestScoped;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

@RequestScoped
public class AuditoriaBO {

    private static final List<LogAuditoriaDTO> logs = new ArrayList<>();

    // REGISTRAR um login
    public void registrarLogin(String usuario) {
        String dataHora = LocalDateTime.now()
                .format(DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm"));
        logs.add(new LogAuditoriaDTO("Login Realizado", usuario, dataHora));
    }

    // LISTAR
    public List<LogAuditoriaDTO> listar() {
        return logs;
    }

    public int contar() {
        return logs.size();
    }
    public List<LogAuditoriaDTO> ultimos() {
        int total = logs.size();
        if (total <= 3) {
            return logs;
        }
        return logs.subList(total - 3, total);
    }
}