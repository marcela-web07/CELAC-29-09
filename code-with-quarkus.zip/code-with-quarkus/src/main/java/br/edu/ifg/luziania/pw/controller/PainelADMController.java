package br.edu.ifg.luziania.pw.controller;

import br.edu.ifg.luziania.pw.model.bo.UsuarioBO;
import br.edu.ifg.luziania.pw.model.bo.AgendamentoBO;
import br.edu.ifg.luziania.pw.model.bo.LogAuditoriaBO;
import br.edu.ifg.luziania.pw.model.dto.AgendamentoDTO;
import br.edu.ifg.luziania.pw.model.dto.LogAuditoriaDTO;
import io.quarkus.qute.CheckedTemplate;
import io.quarkus.qute.TemplateInstance;
import jakarta.inject.Inject;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;

import java.util.List;

@Path("PainelADM")
public class PainelADMController {

    @Inject
    UsuarioBO usuarioBO;

    @Inject
    AgendamentoBO agendamentoBO;

    @Inject
    LogAuditoriaBO auditoriaBO;

    @CheckedTemplate
    public static class Template {
        public static native TemplateInstance painelADM(
                int totalUsuarios,
                int totalAgendamentos,
                int totalLogs,
                List<AgendamentoDTO> ultimosAgendamentos,
                List<LogAuditoriaDTO> ultimosLogs);
    }

    @GET
    @Produces(MediaType.TEXT_HTML)
    public TemplateInstance painelADMPage() {
        return PainelADMController.Template.painelADM(
                usuarioBO.contar(),
                agendamentoBO.contar(),
                auditoriaBO.contar(),
                agendamentoBO.ultimos(),
                auditoriaBO.ultimos()
        );
    }
}