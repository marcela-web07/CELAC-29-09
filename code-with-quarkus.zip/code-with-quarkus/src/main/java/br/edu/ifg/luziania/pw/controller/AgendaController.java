package br.edu.ifg.luziania.pw.controller;

import br.edu.ifg.luziania.pw.model.bo.AgendamentoBO;
import br.edu.ifg.luziania.pw.model.dto.AgendamentoDTO;
import io.quarkus.qute.CheckedTemplate;
import io.quarkus.qute.TemplateInstance;
import jakarta.inject.Inject;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;

@Path("Agenda")
public class AgendaController {

    @Inject
    AgendamentoBO agendamentoBO;

    @CheckedTemplate
    public static class Template {
        public static native TemplateInstance agenda();
    }

    @GET
    @Produces(MediaType.TEXT_HTML)
    public TemplateInstance agendaPage() {
        return AgendaController.Template.agenda();
    }

    @POST
    @Path("agendar")
    @Consumes(MediaType.APPLICATION_JSON)
    public Response agendar(AgendamentoDTO dto) {
        return agendamentoBO.salvar(dto);
    }}