package br.edu.ifg.luziania.pw.controller;

import br.edu.ifg.luziania.pw.model.bo.AgendamentoBO;
import br.edu.ifg.luziania.pw.model.dto.AgendamentoDTO;
import br.edu.ifg.luziania.pw.model.dto.CancelamentoDTO;
import io.quarkus.qute.CheckedTemplate;
import io.quarkus.qute.TemplateInstance;
import jakarta.inject.Inject;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;

import java.util.List;

@Path("MeusAgendamentos")
public class MeusAgendamentosController {

    @Inject
    AgendamentoBO agendamentoBO;

    @CheckedTemplate
    public static class Template {
        public static native TemplateInstance meusAgendamentos();
    }

    @GET
    @Produces(MediaType.TEXT_HTML)
    public TemplateInstance meusAgendamentosPage() {
        return MeusAgendamentosController.Template.meusAgendamentos();
    }

    @GET
    @Path("listar")
    @Produces(MediaType.APPLICATION_JSON)
    public Response listar(@QueryParam("email") String email) {
        List<AgendamentoDTO> lista = agendamentoBO.listarPorEmail(email);
        return Response.ok(lista).build();
    }

    @POST
    @Path("cancelar")
    @Consumes(MediaType.APPLICATION_JSON)
    public Response cancelar(CancelamentoDTO dto) {
        return agendamentoBO.cancelar(dto.getId());
    }
}