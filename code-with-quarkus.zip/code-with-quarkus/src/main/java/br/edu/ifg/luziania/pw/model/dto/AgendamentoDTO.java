package br.edu.ifg.luziania.pw.model.dto;

//atributos
public class AgendamentoDTO {
    private Integer id;
    private String paciente;
    private String procedimento;
    private String data;
    private String horario;
    private String observacoes;
    private String emailUsuario;
    private String status;

    //construtor vazio objt
    public AgendamentoDTO() {
        id = null;
        paciente = "";
        procedimento = "";
        data = "";
        horario = "";
        observacoes = "";
        emailUsuario = "";
        status = "ATIVO"; // todo agendamento novo nasce ativo
    }

    //construtor completo com id (montar dados dentro (da query JPQL do AgendamentoDAO)
    public AgendamentoDTO(Integer id, String paciente, String procedimento, String data, String horario, String observacoes, String emailUsuario, String status) {
        this.id = id;
        this.paciente = paciente;
        this.procedimento = procedimento;
        this.data = data;
        this.horario = horario;
        this.observacoes = observacoes;
        this.emailUsuario = emailUsuario;
        this.status = status;
    }

    // adiciona getter e setter:
    public Integer getId() { return id; }
    public void setId(Integer id) { this.id = id; }
    //get e set
    public String getPaciente() { return paciente; }
    public void setPaciente(String paciente) { this.paciente = paciente; }

    public String getProcedimento() { return procedimento; }
    public void setProcedimento(String procedimento) { this.procedimento = procedimento; }

    public String getData() { return data; }
    public void setData(String data) { this.data = data; }

    public String getHorario() { return horario; }
    public void setHorario(String horario) { this.horario = horario; }

    public String getObservacoes() { return observacoes; }
    public void setObservacoes(String observacoes) { this.observacoes = observacoes; }

    public String getEmailUsuario() { return emailUsuario; }
    public void setEmailUsuario(String emailUsuario) { this.emailUsuario = emailUsuario; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
}