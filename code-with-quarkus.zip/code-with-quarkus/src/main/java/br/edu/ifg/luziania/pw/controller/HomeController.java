package br.edu.ifg.luziania.pw.controller;

import io.quarkus.qute.CheckedTemplate;
import io.quarkus.qute.TemplateInstance;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;



@Path("Home")
public class HomeController {

    @CheckedTemplate
    public static class Template {
        public static native TemplateInstance home();
    }

    @GET
    @Produces(MediaType.TEXT_HTML)
    public TemplateInstance homepage() {
        return HomeController.Template.home();

    }
}