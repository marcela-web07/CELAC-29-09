package br.edu.ifg.luziania.pw.model.dto;

//atributos
public class CadastroDTO {
    private String nome;
    private String email;
    private String senha;
    private String perfil;   // "CLIENTE" ou "ADM"

    //construtor vazio
    public CadastroDTO() {
        nome = "";
        email = "";
        senha = "";
        perfil = "CLIENTE";   // todo novo cadastro começa como cliente
    }

    //construtor completo
    public CadastroDTO(String nome, String email, String senha, String perfil) {
        this.nome = nome;
        this.email = email;
        this.senha = senha;
        this.perfil = perfil;
    }

    //get e set
    public String getNome() { return nome; }
    public void setNome(String nome) { this.nome = nome; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public String getSenha() { return senha; }
    public void setSenha(String senha) { this.senha = senha; }

    public String getPerfil() { return perfil; }
    public void setPerfil(String perfil) { this.perfil = perfil; }
}