package br.edu.ifg.luziania.pw.model.dto;

import jakarta.enterprise.context.ApplicationScoped;
import java.util.ArrayList;
import java.util.List;

@ApplicationScoped
public class UsuarioRepository {

    private final List<CadastroDTO> usuarios = new ArrayList<>();

    public UsuarioRepository() {
        // um ADM inicial fixo, pra você conseguir entrar no painel e testar
        usuarios.add(new CadastroDTO("Admin Master", "admin@celac.com", "admin123", "ADM"));
    }

    // salva um novo usuário (cadastro)
    public void salvar(CadastroDTO usuario) {
        usuarios.add(usuario);
    }

    // lista todos os usuários (pra tela de gerenciamento)
    public List<CadastroDTO> listar() {
        return usuarios;
    }

    // busca um usuário pelo email
    public CadastroDTO buscarPorEmail(String email) {
        for (CadastroDTO u : usuarios) {
            if (u.getEmail().equals(email)) {
                return u;
            }
        }
        return null;  // não encontrou
    }

    // promove um usuário a ADM
    public void promover(String email) {
        CadastroDTO u = buscarPorEmail(email);
        if (u != null) {
            u.setPerfil("ADM");
        }
    }

    // rebaixa um ADM de volta pra cliente
    public void rebaixar(String email) {
        CadastroDTO u = buscarPorEmail(email);
        if (u != null) {
            u.setPerfil("CLIENTE");
        }
    }
}