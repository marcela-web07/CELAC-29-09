package br.edu.ifg.luziania.pw.controller;

import br.edu.ifg.luziania.pw.model.bo.UsuarioBO;
import br.edu.ifg.luziania.pw.model.dto.CadastroDTO;
import io.quarkus.qute.CheckedTemplate;
import io.quarkus.qute.TemplateInstance;
import jakarta.inject.Inject;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;

import java.util.List;

@Path("GerenciarUsuarios")
public class GerenciarUsuariosController {

    @Inject
    UsuarioBO usuarioBO;

    @CheckedTemplate
    public static class Template {
        public static native TemplateInstance gerenciarUsuarios(List<CadastroDTO> usuarios);
    }

    @GET
    @Produces(MediaType.TEXT_HTML)
    public TemplateInstance gerenciarUsuariosPage() {
        List<CadastroDTO> usuarios = usuarioBO.listar();
        return GerenciarUsuariosController.Template.gerenciarUsuarios(usuarios);
    }

    @POST
    @Path("promover")
    @Consumes(MediaType.APPLICATION_JSON)
    public Response promover(CadastroDTO dto) {
        return usuarioBO.promover(dto.getEmail());
    }

    @POST
    @Path("rebaixar")
    @Consumes(MediaType.APPLICATION_JSON)
    public Response rebaixar(CadastroDTO dto) {
        return usuarioBO.rebaixar(dto.getEmail());
    }
}