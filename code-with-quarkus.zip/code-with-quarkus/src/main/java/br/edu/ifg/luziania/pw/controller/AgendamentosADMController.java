package br.edu.ifg.luziania.pw.controller;

import br.edu.ifg.luziania.pw.model.bo.AgendamentoBO;
import br.edu.ifg.luziania.pw.model.dto.AgendamentoDTO;
import io.quarkus.qute.CheckedTemplate;
import io.quarkus.qute.TemplateInstance;
import jakarta.inject.Inject;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;

import java.util.List;

@Path("AgendamentosADM")
public class AgendamentosADMController {

    @Inject
    AgendamentoBO agendamentoBO;

    @CheckedTemplate
    public static class Template {
        public static native TemplateInstance agendamentosADM(List<AgendamentoDTO> agendamentos);
    }

    @GET
    @Produces(MediaType.TEXT_HTML)
    public TemplateInstance agendamentosADMPage() {
        List<AgendamentoDTO> agendamentos = agendamentoBO.listarTodos();
        return AgendamentosADMController.Template.agendamentosADM(agendamentos);
    }
}