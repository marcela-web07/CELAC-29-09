package br.edu.ifg.luziania.pw.controller;

import io.quarkus.qute.CheckedTemplate;
import io.quarkus.qute.TemplateInstance;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;



@Path("Servicos")
public class ServicosController {

    @CheckedTemplate
    public static class Template {
        public static native TemplateInstance servicos();
    }

    @GET
    @Produces(MediaType.TEXT_HTML)
    public TemplateInstance servicos() {
        return ServicosController.Template.servicos();

    }
}
