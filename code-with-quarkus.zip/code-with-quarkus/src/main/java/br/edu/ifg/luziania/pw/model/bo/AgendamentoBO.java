package br.edu.ifg.luziania.pw.model.bo;

import br.edu.ifg.luziania.pw.model.dao.AgendamentoDAO;
import br.edu.ifg.luziania.pw.model.dto.AgendamentoDTO;
import br.edu.ifg.luziania.pw.model.entity.Agendamento;
import jakarta.enterprise.context.RequestScoped;
import jakarta.inject.Inject;
import jakarta.transaction.Transactional;
import jakarta.ws.rs.core.Response;

import java.util.List;

@RequestScoped
public class AgendamentoBO {

    @Inject
    AgendamentoDAO dao;

    @Transactional
    public Response salvar(AgendamentoDTO dto) {
        if (dto.getProcedimento().isEmpty() || dto.getData().isEmpty() || dto.getHorario().isEmpty()) {
            return Response.status(Response.Status.BAD_REQUEST).build();
        }

        Agendamento entity = new Agendamento(dto);

        if (entity.getId() == null) {
            dao.insert(entity);
            dto.setId(entity.getId());
        } else {
            dao.update(entity);
        }

        return Response.ok(dto).build();
    }

    public int contar() {
        return dao.listarTodos().size();
    }

    public Response listar() {
        List<AgendamentoDTO> lista = dao.listarTodos();
        return Response.ok(lista).build();
    }

    public List<AgendamentoDTO> listarTodos() {
        return dao.listarTodos();
    }

    public List<AgendamentoDTO> listarPorEmail(String email) {
        return dao.listarPorEmail(email);
    }

    public List<AgendamentoDTO> ultimos() {
        List<AgendamentoDTO> lista = dao.listarTodos();
        int total = lista.size();
        if (total <= 3) {
            return lista;
        }
        return lista.subList(total - 3, total);
    }

    @Transactional
    public Response cancelar(Integer id) {
        Agendamento entity = dao.buscarPorId(id);
        if (entity == null) {
            return Response.status(Response.Status.NOT_FOUND).build();
        }
        entity.setStatus("CANCELADO");
        dao.update(entity);
        return Response.ok().build();
    }
}