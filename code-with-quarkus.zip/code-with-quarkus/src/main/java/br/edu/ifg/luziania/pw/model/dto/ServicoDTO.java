package br.edu.ifg.luziania.pw.model.dto;

//atributos
public class ServicoDTO {
    private Integer id;
    private String nome;
    private String descricao;
    private Double valor;

    //construtor vazio
    public ServicoDTO() {
        id = null;
        nome = "";
        descricao = "";
        valor = 0.0;
    }

    //construtor completo com id (usado pela query JPQL do ServicoDAO)
    public ServicoDTO(Integer id, String nome, String descricao, Double valor) {
        this.id = id;
        this.nome = nome;
        this.descricao = descricao;
        this.valor = valor;
    }

    public Integer getId() { return id; }
    public void setId(Integer id) { this.id = id; }

    public String getNome() { return nome; }
    public void setNome(String nome) { this.nome = nome; }

    public String getDescricao() { return descricao; }
    public void setDescricao(String descricao) { this.descricao = descricao; }

    public Double getValor() { return valor; }
    public void setValor(Double valor) { this.valor = valor; }
}