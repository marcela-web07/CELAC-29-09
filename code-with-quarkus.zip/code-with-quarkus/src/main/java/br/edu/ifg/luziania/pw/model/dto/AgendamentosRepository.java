package br.edu.ifg.luziania.pw.model.dto;

import jakarta.enterprise.context.ApplicationScoped;
import java.util.ArrayList;
import java.util.List;

@ApplicationScoped
public class AgendamentosRepository {

    private final List<AgendamentoDTO> agendamentos = new ArrayList<>();

    public void salvar(AgendamentoDTO agendamento) {
        agendamentos.add(agendamento);
    }

    public List<AgendamentoDTO> listar() {
        return agendamentos;

    }
        public void remover(int indice) {
            if (indice >= 0 && indice < agendamentos.size()) {
                agendamentos.remove(indice);
            }

    }
}