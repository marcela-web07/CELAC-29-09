package br.edu.ifg.luziania.pw.controller;

import io.quarkus.qute.CheckedTemplate;
import io.quarkus.qute.TemplateInstance;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;

@Path("Desing")
public class DesingController {

    @CheckedTemplate
    public static class Templates {
        public static native TemplateInstance desing();
    }


    @GET
    @Produces(MediaType.TEXT_HTML)
    public TemplateInstance desing() {
        return Templates.desing();
    }

}

