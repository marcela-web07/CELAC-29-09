package br.edu.ifg.luziania.pw.controller;

import br.edu.ifg.luziania.pw.model.bo.LogAuditoriaBO;
import br.edu.ifg.luziania.pw.model.dto.LogAuditoriaDTO;
import io.quarkus.qute.CheckedTemplate;
import io.quarkus.qute.TemplateInstance;
import jakarta.inject.Inject;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;

import java.util.List;

@Path("LogsADM")
public class LogsADMController {

    @Inject
    LogAuditoriaBO auditoriaBO;

    @CheckedTemplate
    public static class Template {
        public static native TemplateInstance logsADM(List<LogAuditoriaDTO> logs);
    }

    @GET
    @Produces(MediaType.TEXT_HTML)
    public TemplateInstance logsADMPage() {
        List<LogAuditoriaDTO> logs = auditoriaBO.listar();
        return LogsADMController.Template.logsADM(logs);
    }
}