package br.edu.ifg.luziania.pw.model.dao;

import br.edu.ifg.luziania.pw.model.dto.LogAuditoriaDTO;
import br.edu.ifg.luziania.pw.model.entity.LogAuditoria;
import jakarta.enterprise.context.RequestScoped;
import jakarta.inject.Inject;
import jakarta.persistence.EntityManager;

import java.util.List;

@RequestScoped
public class LogAuditoriaDAO {

    @Inject
    EntityManager entityManager;

    public void insert(LogAuditoria entity) {
        entityManager.persist(entity);
    }

    public void update(LogAuditoria entity) {
        entityManager.merge(entity);
    }

    public void delete(LogAuditoria entity) {
        entityManager.remove(entity);
    }

    public List<LogAuditoriaDTO> listarTodos() {
        //language=jpql
        String jpql = "select new br.edu.ifg.luziania.pw.model.dto.LogAuditoriaDTO(" +
                "l.id, l.acao, l.usuario, l.dataHora) " +
                "from LogAuditoria l";
        return entityManager.createQuery(jpql, LogAuditoriaDTO.class).getResultList();
    }
}