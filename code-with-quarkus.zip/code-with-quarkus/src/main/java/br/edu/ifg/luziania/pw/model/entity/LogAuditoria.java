package br.edu.ifg.luziania.pw.model.entity;

import br.edu.ifg.luziania.pw.model.dto.LogAuditoriaDTO;
import jakarta.persistence.*;

@Entity
@Table(name = "log_auditoria")
public class LogAuditoria {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    private String acao;
    private String usuario;
    private String dataHora;

    // construtor vazio (obrigatório pro ORM)
    public LogAuditoria() {
    }

    // construtor que recebe o DTO
    public LogAuditoria(LogAuditoriaDTO dto) {
        this.id = dto.getId();
        this.acao = dto.getAcao();
        this.usuario = dto.getUsuario();
        this.dataHora = dto.getDataHora();
    }

    // getters e setters
    public Integer getId() { return id; }
    public void setId(Integer id) { this.id = id; }

    public String getAcao() { return acao; }
    public void setAcao(String acao) { this.acao = acao; }

    public String getUsuario() { return usuario; }
    public void setUsuario(String usuario) { this.usuario = usuario; }

    public String getDataHora() { return dataHora; }
    public void setDataHora(String dataHora) { this.dataHora = dataHora; }
}