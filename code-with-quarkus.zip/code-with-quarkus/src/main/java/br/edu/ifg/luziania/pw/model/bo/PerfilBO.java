package br.edu.ifg.luziania.pw.model.bo;

import br.edu.ifg.luziania.pw.model.dao.PerfilDAO;
import br.edu.ifg.luziania.pw.model.dto.PerfilDTO;
import br.edu.ifg.luziania.pw.model.entity.Perfil;
import jakarta.enterprise.context.RequestScoped;
import jakarta.inject.Inject;
import jakarta.transaction.Transactional;
import jakarta.ws.rs.core.Response;

import java.util.List;

@RequestScoped
public class PerfilBO {

    @Inject
    PerfilDAO dao;

    @Transactional
    public Response salvar(PerfilDTO dto) {
        Perfil entity = new Perfil(dto);

        if (entity.getId() == null) {
            dao.insert(entity);       // é novo → insere
            dto.setId(entity.getId());
        } else {
            dao.update(entity);       // já existe → atualiza
        }

        return Response.ok(dto).build();
    }

    public Response listar() {
        List<PerfilDTO> lista = dao.listarTodos();
        return Response.ok(lista).build();
    }
}