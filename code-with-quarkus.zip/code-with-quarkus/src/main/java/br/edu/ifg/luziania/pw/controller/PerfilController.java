package br.edu.ifg.luziania.pw.controller;

import br.edu.ifg.luziania.pw.model.bo.PerfilBO;
import br.edu.ifg.luziania.pw.model.dto.PerfilDTO;
import io.quarkus.qute.CheckedTemplate;
import io.quarkus.qute.TemplateInstance;
import jakarta.inject.Inject;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;

@Path("Perfil")
public class PerfilController {

    @Inject
    PerfilBO bo;

    @CheckedTemplate
    public static class Template {
        public static native TemplateInstance perfil();
    }

    @GET
    @Produces(MediaType.TEXT_HTML)
    public TemplateInstance perfilPage() {
        return PerfilController.Template.perfil();
    }

    @POST
    @Path("salvar")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response salvar(PerfilDTO dto) {
        return bo.salvar(dto);
    }

    @GET
    @Path("listar")
    @Produces(MediaType.APPLICATION_JSON)
    public Response listar() {
        return bo.listar();
    }
}