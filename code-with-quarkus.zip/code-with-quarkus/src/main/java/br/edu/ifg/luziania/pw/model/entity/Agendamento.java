package br.edu.ifg.luziania.pw.model.entity;

import br.edu.ifg.luziania.pw.model.dto.AgendamentoDTO;
import jakarta.persistence.*;

@Entity
@Table(name = "agendamento")
public class Agendamento {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    private String procedimento;
    private String data;
    private String horario;
    private String observacoes;
    private String paciente;
    private String emailUsuario;
    private String status;

    // construtor vazio (obrigatório pro ORM)
    public Agendamento() {
    }

    // construtor que recebe o DTO
    public Agendamento(AgendamentoDTO dto) {
        this.id = dto.getId();
        this.paciente = dto.getPaciente();
        this.procedimento = dto.getProcedimento();
        this.data = dto.getData();
        this.horario = dto.getHorario();
        this.observacoes = dto.getObservacoes();
        this.emailUsuario = dto.getEmailUsuario();
        this.status = dto.getStatus();
    }

    // getters e setters
    public Integer getId() { return id; }
    public void setId(Integer id) { this.id = id; }

    public String getProcedimento() { return procedimento; }
    public void setProcedimento(String procedimento) { this.procedimento = procedimento; }

    public String getData() { return data; }
    public void setData(String data) { this.data = data; }

    public String getHorario() { return horario; }
    public void setHorario(String horario) { this.horario = horario; }

    public String getObservacoes() { return observacoes; }
    public void setObservacoes(String observacoes) { this.observacoes = observacoes; }

    public String getPaciente() { return paciente; }
    public void setPaciente(String paciente) { this.paciente = paciente; }

    public String getEmailUsuario() { return emailUsuario; }
    public void setEmailUsuario(String emailUsuario) { this.emailUsuario = emailUsuario; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
}