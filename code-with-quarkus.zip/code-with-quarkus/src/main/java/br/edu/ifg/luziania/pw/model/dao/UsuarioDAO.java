package br.edu.ifg.luziania.pw.model.dao;

import br.edu.ifg.luziania.pw.model.entity.Usuario;
import jakarta.enterprise.context.RequestScoped;
import jakarta.inject.Inject;
import jakarta.persistence.EntityManager;

import java.util.List;

@RequestScoped
public class UsuarioDAO {

    @Inject
    EntityManager entityManager;

    public void insert(Usuario entity) {
        entityManager.persist(entity);
    }

    public void update(Usuario entity) {
        entityManager.merge(entity);
    }

    public void delete(Usuario entity) {
        entityManager.remove(entity);
    }

    public Usuario buscarPorEmail(String email) {
        //language=jpql
        String jpql = "from Usuario u where u.email = :email";
        List<Usuario> lista = entityManager.createQuery(jpql, Usuario.class)
                .setParameter("email", email)
                .getResultList();
        return lista.isEmpty() ? null : lista.get(0);
    }

    public List<Usuario> listarTodos() {
        //language=jpql
        String jpql = "from Usuario u";
        return entityManager.createQuery(jpql, Usuario.class).getResultList();
    }
}