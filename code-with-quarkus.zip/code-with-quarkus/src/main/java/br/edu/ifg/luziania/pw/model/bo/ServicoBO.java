package br.edu.ifg.luziania.pw.model.bo;

import br.edu.ifg.luziania.pw.model.dao.ServicoDAO;
import br.edu.ifg.luziania.pw.model.dto.ServicoDTO;
import br.edu.ifg.luziania.pw.model.entity.Servico;
import jakarta.enterprise.context.RequestScoped;
import jakarta.inject.Inject;
import jakarta.transaction.Transactional;
import jakarta.ws.rs.core.Response;

import java.util.List;

@RequestScoped
public class ServicoBO {

    @Inject
    ServicoDAO dao;

    @Inject
    LogAuditoriaBO auditoriaBO;

    @Transactional
    public Response salvar(ServicoDTO dto) {
        if (dto.getNome().isEmpty() || dto.getDescricao().isEmpty()) {
            return Response.status(Response.Status.BAD_REQUEST).build();
        }

        Servico entity = new Servico(dto);

        if (entity.getId() == null) {
            dao.insert(entity);
            dto.setId(entity.getId());
            auditoriaBO.registrar("Serviço cadastrado: " + entity.getNome(), "ADM");
        } else {
            dao.update(entity);
            auditoriaBO.registrar("Serviço atualizado: " + entity.getNome(), "ADM");
        }

        return Response.ok(dto).build();
    }

    public List<ServicoDTO> listarTodos() {
        return dao.listarTodos();
    }

    public int contar() {
        return dao.listarTodos().size();
    }
}