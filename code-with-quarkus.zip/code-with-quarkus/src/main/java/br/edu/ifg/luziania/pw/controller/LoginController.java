package br.edu.ifg.luziania.pw.controller;

import br.edu.ifg.luziania.pw.model.bo.UsuarioBO;
import br.edu.ifg.luziania.pw.model.bo.LogAuditoriaBO;
import br.edu.ifg.luziania.pw.model.dto.AutenticacaoDTO;
import io.quarkus.qute.CheckedTemplate;
import io.quarkus.qute.TemplateInstance;
import jakarta.inject.Inject;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;

@Path("Login")
public class LoginController {

    @Inject
    UsuarioBO usuarioBO;

    @Inject
    LogAuditoriaBO auditoriaBO;

    @CheckedTemplate
    public static class Template {
        public static native TemplateInstance login();
    }

    @GET
    @Produces(MediaType.TEXT_HTML)
    public TemplateInstance loginPage() {
        return LoginController.Template.login();
    }

    @POST
    @Path("autenticar")
    @Consumes(MediaType.APPLICATION_JSON)
    public Response autenticar(AutenticacaoDTO dto) {
        return usuarioBO.autenticar(dto.getIdentificador(), dto.getSenha());
    }
}